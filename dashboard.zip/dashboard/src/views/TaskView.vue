<template>
    <div class="grid justify-items-center  items-center h-full p-4">
        <p class="text-white text-xl">Task List</p>
        <img src="../assets/task.svg" class="w-[80%]" alt="">
    </div>
</template>