<template>
    <div class="grid justify-items-center  items-center h-full p-4">
        <p class="text-white text-xl">Settings</p>
        <img src="../assets/settings.svg" class="w-[80%]" alt="">
    </div>
</template>